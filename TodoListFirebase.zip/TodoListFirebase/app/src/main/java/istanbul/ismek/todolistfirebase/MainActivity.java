package istanbul.ismek.todolistfirebase;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    List<NotItem> notItemList;
    RecyclerView listRV;
    NotlarRVAdapter notlarRVAdapter;
    LinearLayoutManager linearLayoutManager;

    FirebaseDatabase database;
    DatabaseReference notlarRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = FirebaseDatabase.getInstance();

        notlarRef = database.getReference("NOTLAR");
        notItemList = new ArrayList<>();

        listRV=findViewById(R.id.taskList);
        linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        listRV.setLayoutManager(linearLayoutManager);


        notlarRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                notItemList.clear();

                for (DataSnapshot cursorSnapshot : dataSnapshot.getChildren()) {

                    NotItem notItem =cursorSnapshot.getValue(NotItem.class);
                    notItemList.add(notItem);
                }

                notlarRVAdapter=new NotlarRVAdapter(notItemList,getApplicationContext());

                listRV.setAdapter(notlarRVAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


}


package istanbul.ismek.todolistfirebase;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class NotlarRVAdapter extends RecyclerView.Adapter<NotlarRVAdapter.NotlarHolder> {

    List<NotItem> notItemList;
    Context context;

    public NotlarRVAdapter(List<NotItem> notItemList, Context context) {
        this.notItemList = notItemList;
        this.context = context;
    }

    @NonNull
    @Override
    public NotlarHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View rowView;
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        rowView = layoutInflater.inflate(R.layout.row_layout, null);
        NotlarHolder notlarHolder = new NotlarHolder(rowView);
        return notlarHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull NotlarHolder notlarHolder, int i) {
        final NotItem notItem = notItemList.get(i);

        notlarHolder.nameTV.setText(notItem.getName());
        notlarHolder.statusTV.setText(notItem.getStatus());
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        final DatabaseReference notlarRef = database.getReference("NOTLAR");

        notlarHolder.nameTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference not = notlarRef.child(notItem.getId());
                DatabaseReference durumu =not.child("status");

                durumu.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue()!=null)
                        Toast.makeText(context, dataSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        notlarHolder.nameTV.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                DatabaseReference not = notlarRef.child(notItem.getId());
                 not.removeValue();


                return false;
            }
        });

        notlarHolder.statusTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference not = notlarRef.child(notItem.getId());
                DatabaseReference durumu =not.child("status");

                durumu.setValue("GÜNCELLENDİ");

            }
        });



    }

    @Override
    public int getItemCount() {
        return notItemList.size();
    }

    class NotlarHolder extends RecyclerView.ViewHolder {

TextView nameTV,statusTV;
        public NotlarHolder(@NonNull View itemView) {
            super(itemView);

            nameTV=itemView.findViewById(R.id.name);
            statusTV=itemView.findViewById(R.id.status);

        }
    }
}
